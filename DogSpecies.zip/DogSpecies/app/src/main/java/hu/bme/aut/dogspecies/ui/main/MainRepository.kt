package hu.bme.aut.dogspecies.ui.main

class MainRepository {
}