package hu.bme.aut.dogspecies.persistence

class AppDatabase {
}