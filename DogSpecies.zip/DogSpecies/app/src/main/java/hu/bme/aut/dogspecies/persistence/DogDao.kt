package hu.bme.aut.dogspecies.persistence

class DogDao {
}