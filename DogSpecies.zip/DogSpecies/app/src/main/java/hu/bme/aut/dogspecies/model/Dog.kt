package hu.bme.aut.dogspecies.model

data class Dog (
    val name: String
)