package hu.bme.aut.dogspecies.ui.details

class DetailsViewModel {
}