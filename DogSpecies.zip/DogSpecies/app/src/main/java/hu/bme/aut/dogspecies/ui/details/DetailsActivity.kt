package hu.bme.aut.dogspecies.ui.details

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import hu.bme.aut.dogspecies.R

class DetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
    }

}