object NetworkConfig {
    private const val ENDPOINT_ADDRESS = "https://api.thedogapi.com"
    private const val ENDPOINT_PREFIX = ""
    const val SERVICE_ENDPOINT = ENDPOINT_ADDRESS + ENDPOINT_PREFIX
}
