package hu.bme.aut.dogspecies.network

class DogService {
}